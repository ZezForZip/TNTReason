<?php
namespace ZezForZip\TNTReason;

use pocketmine\plugin\PluginBase;

use pocketmine\Player;
use pocketmine\Server;

use pocketmine\block\Block;
use pocketmine\item\Item;

use pocketmine\event\Listener;
use pocketmine\event\block\BlockPlaceEvent;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use pocketmine\nbt\tag\Tag;
use pocketmine\nbt\tag\NamedTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\CompoundTag;

use pocketmine\level\Level;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\particle\FloatingTextParticle;

use pocketmine\level\sound\EndermanTeleportSound;

use pocketmine\math\vector3;

use pocketmine\inventory\Inventory;

use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as C;

class TNTReason extends PluginBase implements Listener{
	 public function onEnable(){
	      $this->getLogger()->info("§aTNTReason§4TNT §bby ZezForZip has been enabled!");
	      $this->getServer()->getPluginManager()->registerEvents($this,$this);
	      $this->saveDefaultConfig();
	      $this->cfg = $this->getConfig()->getAll();
		}
	 public function onTntActivate(BlockPlaceEvent $event){
	      $player = $event->getPlayer();
	      $block = $event->getBlock();
	      //$nbt = $block->getNamedTag() ?? new CompoundTag("", []);
	      //$nbt->etnt = new StringTag("tnt", "FunctionThatWorks");
	      $x = $block->getX();
	      $y = $block->getY();
	      $z = $block->getZ();
	      if($block->getId() == Block::TNT){
		     if(!$player->isOP()){
			    $event->setCancelled(true);
			    $this->getServer()->getScheduler()->scheduleDelayedTask(new CommandTask($this, $player), 1);
			    $this->spawnParticle($x, $y, $z, $player);
			    $this->spawnParticle($x, $y, $z, $player);
			    $player->getInventory()->removeItem(Item::get(Item::TNT,0,1));
			    return true;
			  }else{
				  $event->setCancelled($this->cfg["tnt.remove.op"]);
			      $this->getServer()->getScheduler()->scheduleDelayedTask(new CommandTask($this, $player), 1);
			      $this->spawnParticle($x, $y, $z, $player);
			      $this->spawnParticle($x, $y, $z, $player);
			      $player->getInventory()->removeItem(Item::get(Item::TNT,0,1));
			      return true;
	         	}
	      }
	  }
	  public function spawnParticle($x, $y, $z, $player){
	       $level = $player->getLevel();
	       $center = new Vector3($x, $y, $z);
          $particle = new PortalParticle($center);
          for($yaw = 0, $y = $center->y; $y < $center->y + 4; $yaw += (M_PI * 2) / 20, $y += 1 / 20){
              $x = -sin($yaw) + $center->x;
              $z = cos($yaw) + $center->z;
              $particle->setComponents($x, $y, $z);
          $level->addParticle($particle);
          $level->addParticle($particle);
		   $level->addSound(new EndermanTeleportSound(new Vector3($x, $y, $z)));
		  }
    }
}